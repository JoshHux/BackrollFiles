
namespace HouraiTeahouse.Networking {

public enum Reliability : byte {
  Reliable = 0,
  Unreliable = 1,
}

}
